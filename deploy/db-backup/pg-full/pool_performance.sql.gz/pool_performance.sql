--
-- PostgreSQL database dump
--

\restrict O9bajvkVA6JvRLZbEU5AFs0TRvLIeZV0uYcV6dPqVlPrEoG6bPG3eonzftnroAd

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: pool_performance; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- PostgreSQL database dump complete
--

\unrestrict O9bajvkVA6JvRLZbEU5AFs0TRvLIeZV0uYcV6dPqVlPrEoG6bPG3eonzftnroAd

